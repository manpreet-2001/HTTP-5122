﻿//#### LAB 4 - FUNCTIONS ####
//PART 3:  SAFE DOG WALKING CHECK 


//================== CREATE YOUR checkTemp FUNCTION
//This function's job is to...
//It needs to receive...
//It will return...



//================== LOGIC THAT OUTPUTS MESSAGES BASED ON FUNCTION RESULTS
