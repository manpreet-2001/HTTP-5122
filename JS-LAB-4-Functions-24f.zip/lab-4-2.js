﻿//#### LAB 4 - FUNCTIONS ####
//PART 2:  AN AVERAGE FUNCTION


//################## CREATE YOUR AVERAGE FUNCTION
//This function takes five numbers and returns their average to one decimal place.



//################## LOGIC THAT OUTPUTS MESSAGES BASED ON FUNCTION RESULTS
