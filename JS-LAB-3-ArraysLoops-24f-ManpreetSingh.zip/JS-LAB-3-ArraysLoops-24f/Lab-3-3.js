//LAB 3 - ARRAYS & LOOPS - PART 3

//PART 3 - SHOPPING CART SHIPPING
//==== VARIABLES ========
var cartItems = [];
var totalPrice = 0;
const shippingThreshold = 35;


//==== LOGIC ========
//CHECK FOR ITEMS UNTIL THRESHOLD IS MET.
while (totalPrice < shippingThreshold) {


	//GET ITEM COST FROM USER
    let itemPrice = prompt("Enter the price of the item:");
	
	
	//CONVERT USER INPUT TO A NUMBER
	itemPrice = parseFloat(itemPrice);
   
	
	//ADD ITEM COST TO RUNNING TOTAL VARIABLE
	if (!isNaN(itemPrice) && itemPrice > 0) {
      
	
	//PUSH ITEM COST TO CART ARRAY
	cartItems.push(itemPrice);
	totalPrice += itemPrice;
} else {
	alert("Please enter a valid price.");
}
}
	


//SEND POPUP MESSAGE TO USER
alert(`Your shipping for this order will be free! Total price: $${totalPrice.toFixed(2)}`);


//SEND OUTPUT TO CONSOLE
console.log("Item prices: " + cartItems.join(" | "));




