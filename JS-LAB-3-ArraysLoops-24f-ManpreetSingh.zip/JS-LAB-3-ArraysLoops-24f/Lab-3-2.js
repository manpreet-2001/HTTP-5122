//LAB 3 - ARRAYS & LOOPS - PART 2


//TEAM MEMBER ARRAY
var ourTeam = ["Manpreet", "Jack", "Kunal", "Pallavi", "Oman"];


//OUTPUT TEAM ARRAY TO JS CONSOLE
console.log("Step 2: Initial team:", ourTeam);



//REMOVE LAST MEMBER
ourTeam.pop();
console.log("Step 4: After removing the last member:", ourTeam);


//ADD SEAN TO FRONT OF ARRAY
ourTeam.unshift("Sean");
console.log("Step 6: After adding Sean to the front:", ourTeam);


//REARRANGE THE ARRAY ALPHABETICALLY
ourTeam.sort();
console.log("Step 8: After sorting alphabetically:", ourTeam);



//OUTPUT REQUIRED MESSAGE TO JS CONSOLE
console.log(`Step 9: We have ${ourTeam.length} people in our group.`);



//LOOP THROUGH ARRAY TO OUTPUT TEAM MEMBERS/NUMBERS TO JS CONSOLE
console.log("Step 10: Group members and their positions:");
for (let i = 0; i < ourTeam.length; i++) {
    console.log(`${ourTeam[i]} is # ${i + 1}.`);
}

