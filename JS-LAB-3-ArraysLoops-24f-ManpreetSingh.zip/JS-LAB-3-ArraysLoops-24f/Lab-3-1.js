//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
var fruits = ["Apple", "Banana", "Orange", "Grape", "Mango"];


//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
alert(fruits[2]);



